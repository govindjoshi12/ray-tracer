var searchData=
[
  ['exponential_20functions',['Exponential functions',['../a00242.html',1,'']]],
  ['experimental_20extensions',['Experimental extensions',['../a00287.html',1,'']]]
];
