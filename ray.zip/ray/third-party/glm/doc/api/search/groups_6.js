var searchData=
[
  ['matrix_20functions',['Matrix functions',['../a00371.html',1,'']]],
  ['matrix_20types',['Matrix types',['../a00283.html',1,'']]],
  ['matrix_20types_20with_20precision_20qualifiers',['Matrix types with precision qualifiers',['../a00284.html',1,'']]]
];
