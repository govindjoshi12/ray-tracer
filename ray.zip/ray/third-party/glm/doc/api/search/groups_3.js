var searchData=
[
  ['floating_2dpoint_20pack_20and_20unpack_20functions',['Floating-Point Pack and Unpack Functions',['../a00372.html',1,'']]]
];
