var searchData=
[
  ['log_5fbase_2ehpp',['log_base.hpp',['../a00046.html',1,'']]]
];
