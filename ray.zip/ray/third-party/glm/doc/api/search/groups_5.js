var searchData=
[
  ['integer_20functions',['Integer functions',['../a00370.html',1,'']]]
];
